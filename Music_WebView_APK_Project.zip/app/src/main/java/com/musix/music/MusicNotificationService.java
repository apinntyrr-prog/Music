package com.musix.music;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;
import android.support.v4.media.session.MediaSessionCompat;

// Shows a "Now Playing" style notification (like Spotify/YouTube Music) with
// Play/Pause and Stop controls, driven by <audio>/<video> play events picked
// up inside the WebView (see the JS bridge injected in MainActivity).
public class MusicNotificationService extends Service {

    public static final String ACTION_PLAY = "com.musix.music.ACTION_PLAY";
    public static final String ACTION_PAUSE = "com.musix.music.ACTION_PAUSE";
    public static final String ACTION_TOGGLE = "com.musix.music.ACTION_TOGGLE";
    public static final String ACTION_STOP = "com.musix.music.ACTION_STOP";

    public static final String BROADCAST_TOGGLE = "com.musix.music.BROADCAST_TOGGLE";
    public static final String BROADCAST_STOP = "com.musix.music.BROADCAST_STOP";

    private static final String CHANNEL_ID = "musix_playback";
    private static final int NOTIF_ID = 1001;

    private MediaSessionCompat mediaSession;
    private boolean isPlaying = false;
    private String currentTitle = "Musix";

    @Override
    public void onCreate() {
        super.onCreate();
        mediaSession = new MediaSessionCompat(this, "MusixSession");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_PLAY.equals(action)) {
            if (intent.hasExtra("title")) currentTitle = intent.getStringExtra("title");
            isPlaying = true;
            startInForeground();
        } else if (ACTION_PAUSE.equals(action)) {
            isPlaying = false;
            updateNotification();
        } else if (ACTION_TOGGLE.equals(action)) {
            sendBroadcast(new Intent(BROADCAST_TOGGLE));
        } else if (ACTION_STOP.equals(action)) {
            sendBroadcast(new Intent(BROADCAST_STOP));
            stopForeground(true);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void startInForeground() {
        createChannelIfNeeded();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, notification);
        }
    }

    private void updateNotification() {
        createChannelIfNeeded();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification());
    }

    private Notification buildNotification() {
        Intent toggleIntent = new Intent(this, MusicNotificationService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePending = PendingIntent.getService(this, 0, toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, MusicNotificationService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent contentIntent = new Intent(this, MainActivity.class);
        PendingIntent contentPending = PendingIntent.getActivity(this, 2, contentIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        int playPauseIcon = isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play;

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(currentTitle)
                .setContentText("Musix")
                .setContentIntent(contentPending)
                .setOngoing(isPlaying)
                .addAction(playPauseIcon, isPlaying ? "Pause" : "Play", togglePending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .build();
    }

    private void createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "Music Playback", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("Shows current playback controls");
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Override
    public void onDestroy() {
        if (mediaSession != null) mediaSession.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
