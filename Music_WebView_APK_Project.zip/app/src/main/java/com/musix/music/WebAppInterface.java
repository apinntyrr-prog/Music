package com.musix.music;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.webkit.JavascriptInterface;

// Bridge exposed to the web page as `window.AndroidAudio`. The injected JS in
// MainActivity listens for play/pause/ended events on any <audio>/<video>
// element on the page and calls these methods, so the site itself never
// needs to be modified to support the native notification.
public class WebAppInterface {
    private final Context context;

    WebAppInterface(Context context) {
        this.context = context.getApplicationContext();
    }

    @JavascriptInterface
    public void onAudioPlay(String title) {
        Intent i = new Intent(context, MusicNotificationService.class);
        i.setAction(MusicNotificationService.ACTION_PLAY);
        i.putExtra("title", (title == null || title.trim().isEmpty()) ? "Musix" : title);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(i);
        } else {
            context.startService(i);
        }
    }

    @JavascriptInterface
    public void onAudioPause() {
        Intent i = new Intent(context, MusicNotificationService.class);
        i.setAction(MusicNotificationService.ACTION_PAUSE);
        context.startService(i);
    }

    @JavascriptInterface
    public void onProgress(double currentTimeSeconds, double durationSeconds) {
        Intent i = new Intent(context, MusicNotificationService.class);
        i.setAction(MusicNotificationService.ACTION_PROGRESS);
        i.putExtra("positionMs", (long) (currentTimeSeconds * 1000));
        i.putExtra("durationMs", (long) (durationSeconds * 1000));
        context.startService(i);
    }

    @JavascriptInterface
    public void onCoverChanged(String url) {
        if (url == null || url.isEmpty()) return;
        Intent i = new Intent(context, MusicNotificationService.class);
        i.setAction(MusicNotificationService.ACTION_COVER);
        i.putExtra("coverUrl", url);
        context.startService(i);
    }
}
