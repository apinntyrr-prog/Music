MUSIC APK - WebView wrapper

Target URL:
https://gavingantampan.netlify.app/

This is a real Android application wrapper, NOT a Chrome/PWA shortcut.

Build on Android:
1. Install AndroidIDE.
2. Extract this ZIP.
3. Open the extracted folder as a Gradle project.
4. Let Gradle sync/download dependencies.
5. Run :app:assembleDebug or use the Build APK option.
6. APK will be under app/build/outputs/apk/debug/app-debug.apk

App name: Music
Package: com.musix.music
