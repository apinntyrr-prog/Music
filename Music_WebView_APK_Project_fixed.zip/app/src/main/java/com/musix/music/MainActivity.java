package com.musix.music;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final String URL = "https://gavintampan.netlify.app/";

    // Injected after every page load: watches all <audio>/<video> elements on
    // the page and reports play/pause/ended state to the native side, so the
    // Android notification can mirror what's actually playing without the
    // website needing any changes.
    private static final String AUDIO_BRIDGE_JS =
        "(function(){" +
        "if (window.__musixAudioBridgeInstalled) return;" +
        "window.__musixAudioBridgeInstalled = true;" +
        "window.__musixCurrentAudio = null;" +
        "function bind(el){" +
        "  if (el.__musixBound) return;" +
        "  el.__musixBound = true;" +
        "  el.addEventListener('play', function(){" +
        "    window.__musixCurrentAudio = el;" +
        "    var t = (document.title || 'Musix').replace(' - Musix','').trim();" +
        "    if (window.AndroidAudio) AndroidAudio.onAudioPlay(t);" +
        "  });" +
        "  el.addEventListener('pause', function(){" +
        "    if (window.AndroidAudio) AndroidAudio.onAudioPause();" +
        "  });" +
        "  el.addEventListener('ended', function(){" +
        "    if (window.AndroidAudio) AndroidAudio.onAudioPause();" +
        "  });" +
        "}" +
        "function scan(){ document.querySelectorAll('audio,video').forEach(bind); }" +
        "scan();" +
        "new MutationObserver(scan).observe(document.documentElement, {childList:true, subtree:true});" +
        "window.__musixToggle = function(){" +
        "  var el = window.__musixCurrentAudio;" +
        "  if (!el) return;" +
        "  if (el.paused) el.play(); else el.pause();" +
        "};" +
        "window.__musixStop = function(){" +
        "  var el = window.__musixCurrentAudio;" +
        "  if (el) el.pause();" +
        "};" +
        // Next/Previous: try known global functions first (kept for backward
        // compatibility), then fall back to finding and clicking whatever
        // next/previous control the page itself renders. This avoids
        // depending on exact function names that may not exist on the page.
        "function musixFindControl(keywords){" +
        "  var candidates = document.querySelectorAll('button, [role=\"button\"], a, svg, [class], [id]');" +
        "  for (var i=0;i<candidates.length;i++){" +
        "    var el = candidates[i];" +
        "    var label = ((el.getAttribute && (el.getAttribute('aria-label')||'')) + ' ' +" +
        "                 (el.getAttribute && (el.getAttribute('title')||'')) + ' ' +" +
        "                 (el.id||'') + ' ' + (el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className || '')).toLowerCase();" +
        "    for (var k=0;k<keywords.length;k++){" +
        "      if (label.indexOf(keywords[k]) !== -1){" +
        "        var clickable = el.closest ? (el.closest('button, [role=\"button\"], a') || el) : el;" +
        "        return clickable;" +
        "      }" +
        "    }" +
        "  }" +
        "  return null;" +
        "}" +
        "window.__musixNext = function(){" +
        "  if (typeof window.NX === 'function') { window.NX(); return; }" +
        "  var btn = musixFindControl(['next','skip-forward','skipforward','forward','berikutnya','selanjutnya']);" +
        "  if (btn && btn.click) btn.click();" +
        "};" +
        "window.__musixPrev = function(){" +
        "  if (typeof window.PV === 'function') { window.PV(); return; }" +
        "  var btn = musixFindControl(['prev','skip-back','skipback','backward','sebelumnya','mundur']);" +
        "  if (btn && btn.click) btn.click();" +
        "};" +
        "})();";

    private WebView webView;
    private BroadcastReceiver notifReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11, 11, 13));
        getWindow().setNavigationBarColor(Color.rgb(11, 11, 13));

        requestNotificationPermissionIfNeeded();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setBackgroundColor(Color.rgb(11, 11, 13));
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidAudio");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(AUDIO_BRIDGE_JS, null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        registerNotificationReceiver();

        webView.loadUrl(URL);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    // Play/Pause/Stop tapped in the notification comes back here as a
    // broadcast, and we forward it into the page via the same JS bridge.
    private void registerNotificationReceiver() {
        notifReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (webView == null) return;
                if (MusicNotificationService.BROADCAST_TOGGLE.equals(intent.getAction())) {
                    webView.evaluateJavascript("window.__musixToggle && window.__musixToggle();", null);
                } else if (MusicNotificationService.BROADCAST_STOP.equals(intent.getAction())) {
                    webView.evaluateJavascript("window.__musixStop && window.__musixStop();", null);
                } else if (MusicNotificationService.BROADCAST_NEXT.equals(intent.getAction())) {
                    webView.evaluateJavascript("window.__musixNext && window.__musixNext();", null);
                } else if (MusicNotificationService.BROADCAST_PREV.equals(intent.getAction())) {
                    webView.evaluateJavascript("window.__musixPrev && window.__musixPrev();", null);
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(MusicNotificationService.BROADCAST_TOGGLE);
        filter.addAction(MusicNotificationService.BROADCAST_STOP);
        filter.addAction(MusicNotificationService.BROADCAST_NEXT);
        filter.addAction(MusicNotificationService.BROADCAST_PREV);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(notifReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(notifReceiver, filter);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (notifReceiver != null) {
            unregisterReceiver(notifReceiver);
        }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
        }
        super.onDestroy();
    }
}
